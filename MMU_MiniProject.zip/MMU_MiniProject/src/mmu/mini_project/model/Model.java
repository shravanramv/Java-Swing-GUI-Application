package mmu.mini_project.model;

/**
 * @author JORDAN
 */

// add, edit, delete, update the database (user, specialization, project) via storage.java
public interface Model {
	
	public void addModel();
	
	public void editModel();
	
	public void deleteModel();
	
	public void updateModel();

}
